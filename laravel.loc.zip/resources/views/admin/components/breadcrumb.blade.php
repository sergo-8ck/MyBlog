<h2>{{$title}}</h2>
<nav class="breadcrumb">
    <a href="{{route('admin.index')}}">{{$parent}}</a>
    <a class="breadcrumb-item" href="#"></a>
    <span class="breadcrumb-item active">{{$active}}</span>
</nav>