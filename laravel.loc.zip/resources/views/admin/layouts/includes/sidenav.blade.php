{{--<div class="col-md-2">--}}
    {{--<div class="sidebar content-box">--}}
        {{--<ul class="nav">--}}
            {{--<li class="current"><a href=""><i></i></a></li>--}}
            {{--<li class="submenu"><a href=""><i></i></a></li>--}}
        {{--</ul>--}}
    {{--</div>--}}
{{--</div>--}}