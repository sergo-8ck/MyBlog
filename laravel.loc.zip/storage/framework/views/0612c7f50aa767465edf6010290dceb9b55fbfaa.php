<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="form-group">
    <label for="">Имя</label>
    <input type="text" class="form-control" name="name" placeholder="Имя" value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php else: ?><?php echo e(isset($user->name) ? $user->name : ""); ?><?php endif; ?>" required>
</div>
<div class="form-group">
    <label for="">Email</label>
    <input type="email" class="form-control" name="email" placeholder="Email" value="<?php if(old('email')): ?><?php echo e(old('email')); ?><?php else: ?><?php echo e(isset($user->email) ? $user->email : ""); ?><?php endif; ?>" required>
</div>
<div class="form-group">
    <label for="">Пароль</label>
    <input type="password" class="form-control" name="password">
</div>
<div class="form-group">
    <label for="">Подтверждение</label>
    <input type="password" class="form-control" name="password_confirmation">
</div>
<div class="form-group">
    <select name="roles[]" multiple>
        <?php $__currentLoopData = $allRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<hr>

<input class="btn btn-primary" onclick="$('#role-form').submit" type="submit" value="Сохранить">