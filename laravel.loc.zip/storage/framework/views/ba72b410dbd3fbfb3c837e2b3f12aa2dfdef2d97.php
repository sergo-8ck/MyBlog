<label for="">Статус</label>
<select name="published" class="form-control">
    <?php if(isset($article->id)): ?>
        <option value="1" <?php if($article->published == 1): ?> selected="" <?php endif; ?>>Опубликовано</option>
        <option value="0" <?php if($article->published == 0): ?> selected="" <?php endif; ?>>Не опубликовано</option>
    <?php else: ?>
        <option value="1">Опубликовано</option>
        <option value="0">Не опубликовано</option>
    <?php endif; ?>
</select>

<label for="">Фамили Имя Отчество</label>
<input type="text" class="form-control" name="title" placeholder="Фамили Имя Отчество" value="<?php echo e(isset($article->title) ? $article->title : ""); ?>" required>

<label for="">Slug (уникальное значение)</label>
<input type="text" class="form-control" name="slug" placeholder="Автоматическая генерация" value="<?php echo e(isset($article->slug) ? $article->slug : ""); ?>" readonly="">

<label for="">Программа обучения</label>
<select class="form-control" name="categories[]" multiple="">

    <?php echo $__env->make('admin.articles.partials.categories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</select>




<label for="">Дата обучения</label>
<input type="date" name="date" class="form-control" value="<?php echo e(old('date', date('Y-m-d'))); ?>" required>
<label for="">Номер удостоверения</label>
<input type="text" class="form-control" name="document" placeholder="Номер удостоверения" value="<?php echo e(isset($article->document) ? $article->document : ""); ?>" required>

<label for="">Комментарий</label>
<textarea class="form-control" id="description" name="description"><?php echo e(isset($article->description) ? $article->description : ""); ?></textarea>

<hr>










<hr>

<input class="btn btn-primary" type="submit" value="Сохранить">