<?php $__env->startSection('title', $article->meta_title); ?>
<?php $__env->startSection('meta_keyword', $article->meta_keyword); ?>
<?php $__env->startSection('meta_description', $article->meta_description); ?>

<?php $__env->startSection('content'); ?>
    <main role="main">
        <div class="container py-4">
        <div class="row">
            <div class="col-sm-12">

                <div class="container py-4">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <h1><?php echo e($article->title); ?></h1>
                        </div>
                        <div class="col-12 col-sm-6">
                            <?php if (\Entrust::hasRole('superuser')) : ?>
                            <form onsubmit="if(confirm('Вы действительно хотите удалить ученика?')){return true}else{return false}" action="<?php echo e(route('admin.article.destroy', $article)); ?>"  method="post">
                                <input type="hidden" name="_method" value="DELETE">
                                <?php echo e(csrf_field()); ?>

                                <a href="<?php echo e(route('admin.article.edit', $article)); ?>" class="btn btn-default"><i class="fa fa-edit"></i></a>
                                <button type="submit" class="btn"><i class="fa fa-trash-o"></i></button>
                            </form>
                            <?php endif; // Entrust::hasRole ?>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-12 col-sm-6 py-4">
                            <p><b>Программа обучения:</b>
                                <?php echo e($article->categories()->pluck('title')->implode(', ')); ?></p>
                            <p><b>Дата обучения:</b> <?php echo $article->date; ?></p>
                            <p><b>Номер удостоверения:</b> <?php echo $article->document; ?></p>

                        </div>
                        <div class="col-12 col-sm-6">
                            <?php echo QrCode::size(200)->margin(2)->generate($_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/blog/article/' . $article->slug);; ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>