<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="jumbotron">
                    <button type="button" class="btn btn-primary">
                        Профессий <span class="badge badge-light"><?php echo e($count_categories); ?></span>
                    </button>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="jumbotron">
                    <button type="button" class="btn btn-primary">
                        Учеников <span class="badge badge-light"><?php echo e($count_articles); ?></span>
                    </button>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="jumbotron">
                    <button type="button" class="btn btn-primary">
                        Администаторов <span class="badge badge-light"><?php echo e($count_users); ?></span>
                    </button>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="jumbotron">
                    <button type="button" class="btn btn-primary">
                        Сегодня <span class="badge badge-light">4</span>
                    </button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-secondary btn-block">Добавить профессию</a>
                <div class="list-group">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e(route('admin.category.edit', $category)); ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($category->title); ?></h5>
                            </div>
                            <p class="mb-1">
                                <?php echo e($category->articles()->count()); ?>

                            </p>
                        </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
            <div class="col-sm-6">

                <a href="<?php echo e(route('admin.article.create')); ?>" class="btn btn-secondary btn-block">Добавить ученика</a>

                <div class="list-group">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.article.edit', $article)); ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($article->title); ?></h5>
                            </div>
                            <p class="mb-1">
                                <?php echo e($article->categories()->pluck('title')->implode(', ')); ?>

                            </p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>