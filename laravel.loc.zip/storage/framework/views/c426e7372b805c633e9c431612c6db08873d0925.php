<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Список пользователей <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Пользователи <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

        <hr>
        <a href="<?php echo e(route('admin.user_managment.user.create')); ?>" class="btn btn-primary pull-right">
            <i class="fa fa-plus-square-o"></i> Создать пользователя
        </a>
        <br>
        <table class="table table-striped">
            <thead>
            <th>Имя</th>
            <th>Email</th>
            <th>Роль</th>
            <th>Действие</th>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($role->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>

                        <form onsubmit="if(confirm('Вы действительно хотите удалить пользователя?')){return true}else{return false}" action="<?php echo e(route('admin.user_managment.user.destroy', $user)); ?>"  method="post">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <a href="<?php echo e(route('admin.user_managment.user.edit', $user)); ?>" class="btn btn-default"><i class="fa fa-edit"></i></a>
                            <button type="submit" class="btn"><i class="fa fa-trash-o"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
                </tr>
            <?php endif; ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="3">
                    <nav aria-label="Page navigation">
                        <ul class="pagination pull-right">
                            <?php echo e($users->links()); ?>

                        </ul>
                    </nav>
                </td>
            </tr>
            </tfoot>
        </table>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>