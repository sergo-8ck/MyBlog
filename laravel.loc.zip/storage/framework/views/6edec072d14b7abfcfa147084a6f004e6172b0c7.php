<label for="">Статус</label>
<select name="published" class="form-control">
    <?php if(isset($category->id)): ?>
        <option value="1" <?php if($category->published == 1): ?> selected="" <?php endif; ?>>Опубликовано</option>
        <option value="0" <?php if($category->published == 0): ?> selected="" <?php endif; ?>>Не опубликовано</option>
    <?php else: ?>
        <option value="1">Опубликовано</option>
        <option value="0">Не опубликовано</option>
    <?php endif; ?>
</select>

<label for="">Название</label>
<input type="text" class="form-control" name="title" placeholder="Название" value="<?php echo e(isset($category->title) ? $category->title : ""); ?>" required>

<label for="">Slug</label>
<input type="text" class="form-control" name="slug" placeholder="Автоматическая генерация" value="<?php echo e(isset($category->slug) ? $category->slug : ""); ?>" readonly="">

<label for="">Родительская категория</label>
<select name="parent_id" class="form-control">
    <option value="0">-- без родительской категории --</option>
    <?php echo $__env->make('admin.categories.partials.categories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</select>

<hr>

<input class="btn btn-primary" type="submit" value="Сохранить">