<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($category->children->where('published', 1)->count()): ?>

        <a class="dropdown-item" href="<?php echo e(url("/blog/category/$category->slug")); ?>"><?php echo e($category->title); ?></a>

    <?php else: ?>
        <a class="dropdown-item" href="<?php echo e(url("/blog/category/$category->slug")); ?>"><?php echo e($category->title); ?></a>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>