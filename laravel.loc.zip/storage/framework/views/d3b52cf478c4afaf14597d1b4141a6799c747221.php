<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($category->children->where('published', 1)->count()): ?>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="<?php echo e(url("/blog/category/$category->slug")); ?>" role="button" aria-haspopup="true"
               aria-expanded="false">
                <?php echo e($category->title); ?>

            </a>
            <div class="dropdown-menu">
                <?php echo $__env->make('layouts.top_menu_drop', ['categories' => $category->children], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

    <?php else: ?>
        <li class="nav-item">
            <a href="<?php echo e(url("/blog/category/$category->slug")); ?>" class="nav-link"><?php echo e($category->title); ?></a>

    <?php endif; ?>
        </li>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>