<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Изменение роли <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Роли <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <hr>
        <form class="form-horizontal" action="<?php echo e(route('role.update',$role)); ?>" method="post">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo e(csrf_field()); ?>


            
            <?php echo $__env->make('admin.role.partials.edit_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>