<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Список ролей <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Роли <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

        <hr>
        <a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary float-right">
            <i class="fa fa-plus-square-o"></i> Добавить роли
        </a>
        
            
                
            


        
        <br>
        <table class="table table-striped">
            <thead>
            <th>Название</th>
            <th>Display Name</th>
            <th>Описание</th>
            <th>Действие</th>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($role->name); ?></td>
                    <td><?php echo e($role->display_name); ?></td>
                    <td><?php echo e($role->description); ?></td>
                    <td>

                        <form onsubmit="if(confirm('Вы действительно хотите удалить роль?')){return true}else{return false}" action="<?php echo e(route('role.destroy', $role->id)); ?>"  method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo e(csrf_field()); ?>

                            <a href="<?php echo e(route('role.edit', $role->id)); ?>" class="btn btn-default"><i class="fa fa-edit"></i></a>
                            <button type="submit" class="btn"><i class="fa fa-trash-o"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center"><h2>Данные отсутствуют</h2></td>
                </tr>
            <?php endif; ?>
            </tbody>

        </table>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>